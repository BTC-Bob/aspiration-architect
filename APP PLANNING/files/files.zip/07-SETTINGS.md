# Settings
## AspirationArchitect v0.3 Specification

### Context
> **App:** AspirationArchitect — A personal life management app built around 
> three pillars: Love, Health, and Freedom (in that order).
>
> **User:** Single user ("Architect") seeking structure, accountability, 
> and intentional living.
>
> **Tech Stack:** React 18 + Vite, Tailwind CSS, Firebase Auth, 
> Cloud Firestore, PWA
>
> **This Document:** The Settings page (System Configuration) allows the 
> user to customize their experience, configure integrations, manage 
> privacy settings, and control account actions.

### Dependencies

| Depends On | Why |
|------------|-----|
| Firebase Auth | Sign out functionality |
| Google Calendar API | Calendar integration |
| Firestore: users/{userId}/profile | Settings storage |
| Morning Greeting config | Prayer, metrics, questions |

### Key Principles

- Establish connections before configuring features that use them
- Keep commonly-used settings accessible
- Destructive actions at the bottom with confirmation
- Single source of truth for all configuration

---

## Settings Structure

### Section Order

| Position | Section | Purpose |
|----------|---------|---------|
| 1 | Identity Matrix | Who you are |
| 2 | Integrations | What's connected (foundation) |
| 3 | Morning Greeting | Daily ritual configuration |
| 4 | Goals & Targets | What you're aiming for |
| 5 | Notifications | How you're reminded |
| 6 | Privacy & Security | Protection settings |
| 7 | System Info | Reference only |
| 8 | Danger Zone / Session | Destructive actions (last) |

---

## Section 1: Identity Matrix

### Purpose
Establish user identity within the app.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  👤 IDENTITY MATRIX                                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  DESIGNATION / NAME                                             │
│  [ Architect                                    ]               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| Designation / Name | Text | How the app addresses the user |

### Usage

The designation appears in:
- Dashboard greeting: "Good morning, **Architect**"
- Prayer/affirmation references

---

## Section 2: Integrations

### Purpose
Establish connections to external services that other features depend on.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  📅 INTEGRATIONS                                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Google Calendar                                                │
│  [ Connected ✓ ]                               [ Manage → ]     │
│  Shared Family Calendar active                                  │
│                                                                 │
│  Home Address (for travel estimates)                            │
│  [ Set Address → ]                                              │
│  Used for drive time calculations (v0.4+)                       │
│                                                                 │
│  WHOOP (sleep data)                                             │
│  [ Not Connected ]                             [ Link → ]       │
│  Auto-import sleep scores                                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Fields

| Integration | Status | Actions |
|-------------|--------|---------|
| Google Calendar | Connected / Not Connected | Manage (select calendars), Disconnect |
| Home Address | Set / Not Set | Set Address, Edit |
| WHOOP | Connected / Not Connected | Link, Disconnect |

### Google Calendar Management

On "Manage" tap:

```
┌─────────────────────────────────────────────────────────────────┐
│  GOOGLE CALENDAR SETTINGS                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  SELECT CALENDARS TO DISPLAY                                    │
│  ☑ Family Shared Calendar                                       │
│  ☑ Personal                                                     │
│  ☐ Work                                                         │
│  ☐ Holidays                                                     │
│                                                                 │
│              [ Disconnect ]     [ Save ]                        │
└─────────────────────────────────────────────────────────────────┘
```

### Home Address (v0.3 — Manual, v0.4+ — Auto Travel Time)

```
┌─────────────────────────────────────────────────────────────────┐
│  SET HOME ADDRESS                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Street Address                                                 │
│  [ 123 Main Street                              ]               │
│                                                                 │
│  City, State ZIP                                                │
│  [ Anytown, CA 90210                            ]               │
│                                                                 │
│              [ Cancel ]     [ Save ]                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## Section 3: Morning Greeting

### Purpose
Configure all customizable elements of the Morning Greeting ritual.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  🌅 MORNING GREETING                                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Prayer / Affirmation                          [ Edit Text → ]  │
│  Customize your daily affirmation                               │
│                                                                 │
│  Physiology Metrics                            [ Configure → ]  │
│  Currently tracking: Sleep Score, Weight                        │
│                                                                 │
│  Accountability Questions                      [ Manage → ]     │
│  2 active questions                                             │
│                                                                 │
│  Default Core Tasks                                             │
│  [ 3 ▼ ]                                                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Prayer / Affirmation Editor

```
┌─────────────────────────────────────────────────────────────────┐
│  EDIT PRAYER / AFFIRMATION                                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  [ As the new day begins, I **embrace** the opportunity         │
│    to **design** a purposeful and **fulfilling** day.           │
│                                                                 │
│    With each morning, I am reminded that every action           │
│    **contributes** to the **blueprint** of my year.             │
│                                                                 │
│    Today, I step forward with **intention** and **clarity**,    │
│    aligning my actions with my long-term **aspirations**.   ]   │
│                                                                 │
│  TIP: Use **double asterisks** to bold words                    │
│                                                                 │
│              [ Cancel ]     [ Save ]                            │
└─────────────────────────────────────────────────────────────────┘
```

### Physiology Metrics Manager

```
┌─────────────────────────────────────────────────────────────────┐
│  PHYSIOLOGY METRICS                                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ACTIVE METRICS                                                 │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ WHOOP SLEEP SCORE              %         [ Edit ] [ ✕ ]   │  │
│  │ MORNING WEIGHT                 lbs       [ Edit ] [ ✕ ]   │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                 │
│  [ + Add Metric ]                                               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

Add/Edit Metric:

```
┌─────────────────────────────────────────────────────────────────┐
│  ADD METRIC                                                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Label                                                          │
│  [ Mood Rating                                  ]               │
│                                                                 │
│  Unit                                                           │
│  [ 1-10                                         ]               │
│                                                                 │
│              [ Cancel ]     [ Save ]                            │
└─────────────────────────────────────────────────────────────────┘
```

### Accountability Questions Manager

```
┌─────────────────────────────────────────────────────────────────┐
│  ACCOUNTABILITY QUESTIONS                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ACTIVE QUESTIONS                                               │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ Digital Sunset                              [ Edit ] [ ✕ ]│  │
│  │ "Did you execute the Shutdown Protocol?"                  │  │
│  │ Linked: Evening Protocol                                  │  │
│  └───────────────────────────────────────────────────────────┘  │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ PureView Integrity Check                    [ Edit ] [ ✕ ]│  │
│  │ "Did you maintain wholesome visual standards?"            │  │
│  │ Penalty: -5 PV (Negative: Integrity Lapse)                │  │
│  └───────────────────────────────────────────────────────────┘  │
│                                                                 │
│  [ + Add Question ]                                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

Add/Edit Question:

```
┌─────────────────────────────────────────────────────────────────┐
│  ADD ACCOUNTABILITY QUESTION                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Title                                                          │
│  [ Digital Sunset                               ]               │
│                                                                 │
│  Question                                                       │
│  [ Did you execute the Shutdown Protocol last night?  ]         │
│                                                                 │
│  Link to Protocol (optional)                                    │
│  [ Evening Protocol ▼ ]                                         │
│  Only shows when this Protocol is active                        │
│                                                                 │
│  Negative PV Category (optional)                                │
│  [ None ▼ ]                                                     │
│  Applied when answer is "No"                                    │
│  [ + Create Negative Category ]                                 │
│                                                                 │
│              [ Cancel ]     [ Save ]                            │
└─────────────────────────────────────────────────────────────────┘
```

### Delete Confirmation

```
┌─────────────────────────────────────────────────────────────────┐
│  ⚠️ Delete Question?                                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Are you sure you want to delete "Digital Sunset"?              │
│  This action cannot be undone.                                  │
│                                                                 │
│              [ Cancel ]     [ Delete ]                          │
└─────────────────────────────────────────────────────────────────┘
```

---

## Section 4: Goals & Targets

### Purpose
Set personal PV benchmarks.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  📊 GOALS & TARGETS                                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Daily PV Target                                                │
│  [ 75 ] PV                                                      │
│  Used for progress bar and daily rating                         │
│                                                                 │
│  Annual PV Goal                                                 │
│  [ 28000 ] PV                                                   │
│  Target for a "Good" year                                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Default Values

| Target | Default | Tier |
|--------|---------|------|
| Daily PV Target | 75 | Good day threshold |
| Annual PV Goal | 28,000 | Good year threshold |

---

## Section 5: Notifications

### Purpose
Configure how and when the app reminds you.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  🔔 NOTIFICATIONS                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Morning Greeting Reminder                                      │
│  [ 6:00 AM ▼ ]                                    [ On / Off ]  │
│  Reminds you to start your day with intention                   │
│                                                                 │
│  Streak Alerts                                                  │
│  [ On / Off ]                                                   │
│  Notifies when you're about to break a streak                   │
│                                                                 │
│  Protocol Reminders                                             │
│  [ On / Off ]                                                   │
│  Time-based reminders for scheduled protocols                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### PWA Notification Limitations

| Feature | PWA Support |
|---------|-------------|
| Push notifications | ✓ Supported (Android, Desktop, iOS Safari 16.4+) |
| Custom sound | ✗ Not supported — uses system default |
| Vibration | ✗ Unreliable |
| Badge count | Limited |

---

## Section 6: Privacy & Security

### Purpose
Protect sensitive journal entries and memorable moments.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  🔒 PRIVACY & SECURITY                                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Privacy PIN                                                    │
│  [ Set PIN → ]                    or              [ Change → ]  │
│  4-digit PIN to protect private entries                         │
│                                                                 │
│  Security Question                                              │
│  [ Update → ]                                                   │
│  Used to recover PIN if forgotten                               │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Set PIN Flow

```
┌─────────────────────────────────────────────────────────────────┐
│  SET PRIVACY PIN                                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Enter 4-digit PIN                                              │
│  [ ● ● ● ● ]                                                    │
│                                                                 │
│  Confirm PIN                                                    │
│  [ ● ● ● ● ]                                                    │
│                                                                 │
│  Security Question                                              │
│  [ What is your mother's maiden name? ▼ ]                       │
│                                                                 │
│  Answer                                                         │
│  [ ____________________________ ]                               │
│                                                                 │
│              [ Cancel ]     [ Save PIN ]                        │
└─────────────────────────────────────────────────────────────────┘
```

### Security Question Options

- What is your mother's maiden name?
- What was the name of your first pet?
- What city were you born in?
- What was your childhood nickname?
- Custom question

---

## Section 7: System Info

### Purpose
Display app version and reference information.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  ℹ️ SYSTEM INFO                                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  System Version              v0.3.0 • Alpha                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Section 8: Danger Zone & Session Control

### Purpose
Destructive actions and session management. Always at bottom.

### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  ┌─────────────────────────┐  ┌─────────────────────────────┐   │
│  │ ⚠️ Danger Zone          │  │ 🚪 Session Control          │   │
│  │                         │  │                             │   │
│  │   [ Factory Reset ]     │  │   [ Sign Out ]              │   │
│  │                         │  │                             │   │
│  └─────────────────────────┘  └─────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Factory Reset Confirmation

```
┌─────────────────────────────────────────────────────────────────┐
│  ⚠️ FACTORY RESET                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  This will permanently delete ALL your data including:          │
│  • All tasks, habits, and protocols                             │
│  • All daily logs and history                                   │
│  • All journal entries                                          │
│  • All milestones and streaks                                   │
│  • All settings and preferences                                 │
│                                                                 │
│  This action CANNOT be undone.                                  │
│                                                                 │
│  Type "RESET" to confirm:                                       │
│  [ ____________ ]                                               │
│                                                                 │
│              [ Cancel ]     [ Reset Everything ]                │
└─────────────────────────────────────────────────────────────────┘
```

---

## Firestore Schema

### User Profile/Settings

```javascript
// users/{userId}/profile/settings
{
	identity: {
		designation: "Architect"
	},
	integrations: {
		googleCalendar: {
			connected: true,
			selectedCalendars: ["family-shared", "personal"]
		},
		homeAddress: {
			street: "123 Main Street",
			cityStateZip: "Anytown, CA 90210"
		},
		whoop: {
			connected: false
		}
	},
	morningGreeting: {
		prayer: {
			text: "As the new day begins...",
			boldWords: ["embrace", "design", "fulfilling"]
		},
		physiologyMetrics: [
			{ id: "sleep", label: "WHOOP SLEEP SCORE", unit: "%" },
			{ id: "weight", label: "MORNING WEIGHT", unit: "lbs" }
		],
		accountabilityQuestions: [
			{
				id: "q1",
				title: "Digital Sunset",
				description: "Did you execute the Shutdown Protocol?",
				linkedProtocol: "protocol-evening",
				linkedCategory: null
			}
		],
		defaultCoreTaskCount: 3
	},
	goalsAndTargets: {
		dailyPvTarget: 75,
		annualPvGoal: 28000
	},
	notifications: {
		morningGreetingReminder: {
			enabled: true,
			time: "06:00"
		},
		streakAlerts: true,
		protocolReminders: true
	},
	privacy: {
		pinHash: "hashed_pin_value",
		securityQuestion: "What is your mother's maiden name?",
		securityAnswerHash: "hashed_answer_value"
	},
	createdAt: "01-01-2026",
	updatedAt: "01-11-2026"
}
```

---

*Document Version: 0.3.0*
*Last Updated: 01-11-2026*
