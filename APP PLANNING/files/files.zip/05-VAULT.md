# Vault (History)
## AspirationArchitect v0.3 Specification

### Context
> **App:** AspirationArchitect — A personal life management app built around 
> three pillars: Love, Health, and Freedom (in that order).
>
> **User:** Single user ("Architect") seeking structure, accountability, 
> and intentional living.
>
> **Tech Stack:** React 18 + Vite, Tailwind CSS, Firebase Auth, 
> Cloud Firestore, PWA
>
> **This Document:** The Vault is the historical record of the user's 
> journey. It provides multiple views into past data including daily logs, 
> health progress, milestones, streaks, memorable moments, and an 
> annual visualization called "The Architect's Blueprint."

### Dependencies

| Depends On | Why |
|------------|-----|
| dailyLogs collection | Source of all historical data |
| milestones collection | Milestone tracking and display |
| streaks collection | Streak calculations |
| Journal entries | Content for Daily Log and Memorable Moments |

### Key Principles

- Multiple perspectives — view data by day, by metric, by achievement
- Visual inspiration — The Blueprint provides a compelling year view
- Privacy protection — per-entry PIN for sensitive content
- Motivational — highlight progress and accomplishments

---

## Vault Navigation

### Tab Structure

```
┌─────────────────────────────────────────────────────────────────────┐
│  VAULT                                                              │
├─────────────────────────────────────────────────────────────────────┤
│  [Daily Log] [Health] [Milestones] [Streaks] [Memorable] [Annual]   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## View 1: Daily Log

### Purpose
View any single day's complete record.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  DAILY LOG                         [ ← ] 01-11-2026 [ → ]           │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  DAY SUMMARY                                                        │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐                    │
│  │ LOVE        │ │ HEALTH      │ │ FREEDOM     │   TOTAL: 39 PV    │
│  │     12      │ │     18      │ │      9      │   Rating: AVERAGE │
│  └─────────────┘ └─────────────┘ └─────────────┘                    │
│                                                                     │
│  PHYSIOLOGY                                                         │
│  Sleep Score: 82% │ Weight: 183.5 lbs                               │
│                                                                     │
│  TASKS COMPLETED (5/7)                                              │
│  ✓ Deep work on App (2h) — +20 PV                                   │
│  ✓ Gym / Treadmill (1h) — +10 PV                                    │
│  ✓ Call insurance (30m) — +5 PV                                     │
│  ✓ Grocery shopping (30m) — +2 PV                                   │
│  ✓ Water plants (15m) — +1 PV                                       │
│  ✗ Reply to emails — Not completed                                  │
│  ✗ Evening reading — Not completed                                  │
│                                                                     │
│  PROTOCOLS                                                          │
│  ✓ Morning Protocol (7/7) — +15 PV                                  │
│  ✓ Evening Protocol (5/5) — +12 PV                                  │
│                                                                     │
│  JOURNAL ENTRIES                                                    │
│  💬 "Made progress on Morning Greeting redesign" (10:30 AM)         │
│  💭 "Feeling motivated today" (08:30 AM)                            │
│  🔒 Private Entry [ Unlock ]                                        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Features

| Feature | Description |
|---------|-------------|
| Date navigation | Arrows or calendar picker |
| Day rating | Based on PV tier (Poor/Below Average/Average/Good/Exceptional) |
| Pillar breakdown | Shows PV per pillar |
| Task list | All tasks with completion status |
| Protocol summary | Protocols with completion percentage |
| Journal entries | All entries including private (locked) |

---

## View 2: Health Progress

### Purpose
Track health-related metrics over time.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  HEALTH PROGRESS                                                    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  WEIGHT TREND                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  190 ┤                                                       │    │
│  │  185 ┤    ╭──╮                                               │    │
│  │  180 ┤───╯    ╰──────╮                                       │    │
│  │  175 ┤               ╰───── TARGET ─────                     │    │
│  │  170 ┤                                                       │    │
│  │      └─────────────────────────────────────────────          │    │
│  │       Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep            │    │
│  └─────────────────────────────────────────────────────────────┘    │
│  Current: 183.5 lbs │ Target: 175 lbs │ To Go: 8.5 lbs              │
│                                                                     │
│  SLEEP SCORE TREND                                                  │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  100% ┤                                                      │    │
│  │   80% ┤   ╭╮  ╭──╮ ╭╮                                        │    │
│  │   60% ┤──╯  ╰─╯    ╰  ╰──                                    │    │
│  │   40% ┤                                                      │    │
│  │      └────────────────────────────────                       │    │
│  │       Mon  Tue  Wed  Thu  Fri  Sat  Sun                      │    │
│  └─────────────────────────────────────────────────────────────┘    │
│  7-Day Average: 78% │ 30-Day Average: 75%                           │
│                                                                     │
│  HEALTH GOALS                                                       │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ 🎯 Achieve 175 lbs           ████████░░░░░░░ 65%             │    │
│  │    Current: 183.5 │ Started: 195 │ Target: 175               │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Features

| Feature | Description |
|---------|-------------|
| Weight trend | Line chart with target line |
| Sleep trend | Daily or weekly sleep scores |
| Goal progress | Visual progress bar toward health milestones |
| Time range | Toggle: Week / Month / Year / All Time |

---

## View 3: Milestones

### Purpose
Track long-term goal progress and achievements.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  MILESTONES                                                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  IN PROGRESS                                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ 🏆 Launch CNA Packet                            FREEDOM      │    │
│  │    ████████████░░░░░░░░ 60%                    +500 PV       │    │
│  │    Sub-goals: 3/5 complete                                   │    │
│  │    ✓ Complete content outline (+60 PV)                       │    │
│  │    ✓ Design mockups finished (+60 PV)                        │    │
│  │    ✓ Beta testing complete (+60 PV)                          │    │
│  │    ☐ Marketing page live                                     │    │
│  │    ☐ Official launch                                         │    │
│  │    Target: 03-15-2026                                        │    │
│  └─────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ 🎯 Achieve 175 lbs                              HEALTH       │    │
│  │    ████████░░░░░░░░░░░░ 65%                    +300 PV       │    │
│  │    Current: 183.5 │ Target: 175                              │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  ACHIEVED                                                           │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ ✓ 50 Date Nights                               LOVE          │    │
│  │   Completed: 12-20-2025                       +400 PV        │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Features

| Feature | Description |
|---------|-------------|
| In Progress | Active milestones with progress bars |
| Sub-goals | Expandable list of checkpoints |
| Achieved | Completed milestones with dates |
| PV display | Shows total value and earned so far |
| Pillar tag | Color-coded pillar indicator |

---

## View 4: Streaks

### Purpose
Display current and historical streaks for habits and protocols.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  STREAKS                                                            │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ACTIVE STREAKS 🔥                                                  │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ ☀ Morning Protocol          🔥 23 days         Best: 45     │    │
│  │   ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░░░░░░░░░░░░░░          │    │
│  │   Next bonus: +10 PV at 30 days (7 days away)                │    │
│  └─────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ 💧 Daily Hydration          🔥 12 days         Best: 12 🏆   │    │
│  │   ▓▓▓▓▓▓▓▓▓▓▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░          │    │
│  │   Next bonus: +10 PV at 14 days (2 days away)                │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  STREAK MILESTONES EARNED                                           │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ 🏅 7-day streak: Morning Protocol (01-08-2026)      +5 PV    │    │
│  │ 🏅 7-day streak: Daily Hydration (01-05-2026)       +5 PV    │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  BROKEN STREAKS (restart anytime)                                   │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ ☽ Evening Protocol          0 days             Best: 18     │    │
│  │   Last completed: 01-08-2026 (3 days ago)                    │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Streak Bonus Schedule

| Streak Length | Bonus |
|---------------|-------|
| 7 days | +5 PV |
| 14 days | +10 PV |
| 30 days | +25 PV |
| 60 days | +50 PV |
| 90 days | +100 PV |

### Features

| Feature | Description |
|---------|-------------|
| Active streaks | Currently running with day count |
| Best record | Personal best for each streak |
| Next bonus | Days until next bonus milestone |
| Broken streaks | Encouragement to restart (no penalty) |
| Streak history | Log of earned streak bonuses |

---

## View 5: Memorable Moments

### Purpose
Curated collection of significant life moments.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  MEMORABLE MOMENTS ⭐                                                │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  2026                                                               │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ ⭐ 01-11-2026 — 10th Wedding Anniversary                     │    │
│  │    "Anniversary dinner at our favorite restaurant.           │    │
│  │     She loved the surprise dessert."                         │    │
│  │    Category: Relationship / Quality Time │ +18 PV            │    │
│  └─────────────────────────────────────────────────────────────┘    │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ 🔒 01-05-2026 — Private Entry                                │    │
│  │    [ Unlock with PIN ]                                       │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  2025                                                               │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ ⭐ 12-25-2025 — Christmas with Family                        │    │
│  │    "Kids' faces when they opened presents..."                │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Features

| Feature | Description |
|---------|-------------|
| Chronological | Organized by year, then date |
| Entry preview | Truncated text preview |
| Privacy | Private entries show lock icon |
| Tap to expand | Full entry view on selection |

---

## View 6: Annual Summary & Blueprint

### Purpose
Year-at-a-glance visualization and statistics.

### Layout

```
┌─────────────────────────────────────────────────────────────────────┐
│  ANNUAL SUMMARY — 2026                                              │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  YEAR PROGRESS                                                      │
│  Day 11 of 365 │ 3% Complete                                        │
│                                                                     │
│  PV STATUS                                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │ Current: 847 PV │ Target: 28,000 PV │ On Track: ✓            │    │
│  │ ████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░ 3%          │    │
│  │ Projected Year-End: 28,100 PV (GOOD)                         │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                     │
│  PILLAR BALANCE                                                     │
│  Love: 289 PV (34%) ████████████░░░░░░░░░░░░░░░░░░░                 │
│  Health: 312 PV (37%) █████████████░░░░░░░░░░░░░░░░░                │
│  Freedom: 246 PV (29%) ██████████░░░░░░░░░░░░░░░░░░░░               │
│                                                                     │
│  THE ARCHITECT'S BLUEPRINT                                          │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │      JAN    FEB    MAR    APR    ...                         │    │
│  │  S  🟥🟦🟧🟥🟦⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  │  M  🟧🟥🟦🟦🟥⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  │  T  🟦🟧🟥🟧🟦⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  │  W  🟥🟦🟧🟥🟥⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  │  T  🟧🟥🟦🟦🟧⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  │  F  🟦🟧🟧🟥🟦⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  │  S  🟥🟦🟥🟧⭐⬜⬜ ⬜⬜⬜⬜⬜⬜⬜ ...                          │    │
│  └─────────────────────────────────────────────────────────────┘    │
│  🟥 Love │ 🟦 Health │ 🟧 Freedom │ ⬜ Unbuilt │ ⭐ Memorable        │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## The Architect's Blueprint

### Concept
A 365-day grid where each day is a building block, color-coded by dominant pillar.

### Grid Structure

| Dimension | Value |
|-----------|-------|
| Columns | 52 weeks + 1 day |
| Rows | 7 days (Sun–Sat) |
| Total blocks | 365 |

### Block Colors

| State | Color | Hex | Meaning |
|-------|-------|-----|---------|
| Love dominant | Red | #ef4444 | Love had highest PV |
| Health dominant | Cyan | #06b6d4 | Health had highest PV |
| Freedom dominant | Amber | #f59e0b | Freedom had highest PV |
| Balanced | White/Gradient | — | All pillars within 10% |
| Poor day | Faded color | 50% opacity | Day logged but 0-30 PV |
| Unbuilt | Dark gray | #374151 | Future or no data |

### Block Indicators

| Indicator | Meaning |
|-----------|---------|
| ⭐ | Memorable Moment |
| 🏆 | Milestone achieved |
| Current day | Glowing border or pulse |

### Interactions

| Action | Result |
|--------|--------|
| Tap any block | Opens Daily Log for that date |
| Pinch/zoom (mobile) | Zoom into month/week |
| Scroll horizontal | Navigate across year |

---

## Privacy (PIN Protection)

### Protected Content

| Content Type | Protection |
|--------------|------------|
| Private journal entries | Per-entry lock |
| Private memorable moments | Per-entry lock |

### PIN System

| Setting | Value |
|---------|-------|
| Format | 4-digit numeric |
| Recovery | Security question |
| Configuration | Settings page |

### Unlock Flow

1. Tap locked entry
2. PIN prompt appears
3. Enter 4 digits
4. Content revealed
5. Auto-locks on navigation or timeout (5 min)

---

## Firestore Queries

### Daily Log

```javascript
// Get single day
db.collection('users').doc(userId)
  .collection('dailyLogs').doc('01-11-2026')
```

### Health Progress

```javascript
// Get weight entries for chart
db.collection('users').doc(userId)
  .collection('dailyLogs')
  .orderBy('__name__')
  .select('physiology.weight', 'physiology.sleepScore')
```

### Milestones

```javascript
// Get all milestones
db.collection('users').doc(userId)
  .collection('milestones')
  .orderBy('status') // in-progress first
```

### Streaks

```javascript
// Get all streak records
db.collection('users').doc(userId)
  .collection('streaks')
```

### Memorable Moments

```javascript
// Get all memorable entries
db.collection('users').doc(userId)
  .collection('memorableMoments')
  .orderBy('date', 'desc')
```

### Blueprint Data

```javascript
// Get year of daily logs for Blueprint
db.collection('users').doc(userId)
  .collection('dailyLogs')
  .where('__name__', '>=', '01-01-2026')
  .where('__name__', '<=', '12-31-2026')
  .select('pvEarned')
```

---

*Document Version: 0.3.0*
*Last Updated: 01-11-2026*
